// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyCA_n5JxZQqUJeLFt-38H_p7DlAXwvNI3U",
//   authDomain: "softnumen.firebaseapp.com",
//   projectId: "softnumen",
//   storageBucket: "softnumen.appspot.com",
//   messagingSenderId: "1076341602531",
//   appId: "1:1076341602531:web:84db9f30226c3ee4772dd6",
//   measurementId: "G-1CJZNP0JYW",
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
